import React from 'react'

export default class News extends React.Component {
  render() {
    return (
      <div style={{ backgroundColor: 'green' }}>
        这是 News组件 的内容，它是子路由的内容
      </div>
    )
  }
}
