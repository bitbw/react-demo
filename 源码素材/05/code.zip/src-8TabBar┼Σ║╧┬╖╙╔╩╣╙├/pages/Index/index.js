import React from 'react'

export default class Index extends React.Component {
  render() {
    return <div>这是首页</div>
  }
}
