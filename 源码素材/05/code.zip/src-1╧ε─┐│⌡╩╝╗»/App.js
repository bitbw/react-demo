import React from 'react'

function App() {
  return <div className="App">项目根组件</div>
}

export default App
