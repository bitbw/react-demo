import React from 'react'

export default class HouseList extends React.Component {
  render() {
    return <div>列表找房</div>
  }
}
