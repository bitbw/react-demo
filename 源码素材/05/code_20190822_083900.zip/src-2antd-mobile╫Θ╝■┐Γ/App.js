import React from 'react'

// 导入要使用的组件
import { Button } from 'antd-mobile'

function App() {
  return (
    <div className="App">
      项目根组件 <Button>登录</Button>
    </div>
  )
}

export default App
